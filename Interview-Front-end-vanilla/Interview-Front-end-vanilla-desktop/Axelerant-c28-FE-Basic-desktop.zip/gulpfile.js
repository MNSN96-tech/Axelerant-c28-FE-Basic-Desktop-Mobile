const gulp = require('gulp');
const twig = require('gulp-twig');
const sass = require('gulp-sass');
const glob = require('gulp-sass-glob');
const autoprefixer = require('gulp-autoprefixer');
const babel = require('gulp-babel');
const eslint = require('gulp-eslint');
const stylelint = require('gulp-stylelint');
const browserSync = require('browser-sync');
const imagemin = require('gulp-imagemin');
const changed = require('gulp-changed');

gulp.task('twig', () => {
  return gulp
    .src('src/templates/*.twig')
    .pipe(twig())
    .pipe(gulp.dest('dist'));
});

gulp.task('imagemin', function() {
  var imgSrc = 'src/templates/images/*.+(png|jpg|gif|svg)',
  imgDst = 'dist/images';
  
  gulp.src(imgSrc)
  .pipe(changed(imgDst))
  .pipe(imagemin())
  .pipe(gulp.dest(imgDst));
});


gulp.task('sass', () => {
  return gulp
    .src('src/sass/*.scss')
    .pipe(glob())
    .pipe(
      sass({
        includePaths: ['./node_modules']
      })
    )
    .pipe(autoprefixer({ browsers: ['last 2 versions'] }))
    .pipe(gulp.dest('dist'));
});

gulp.task('stylelint', () => {
  return gulp.src('src/sass/*.scss').pipe(
    stylelint({
      reporters: [{ formatter: 'string', console: true }]
    })
  );
});

gulp.task('babel', () => {
  return gulp
    .src('src/js/*.js')
    .pipe(babel())
    .pipe(gulp.dest('dist'));
});

gulp.task('eslint', () => {
  return gulp
    .src(['src/js/*.js'])
    .pipe(eslint())
    .pipe(eslint.format());
});

gulp.task('browsersync', () => {
  browserSync.init({
    server: {
      baseDir: './dist'
    },
    notify: false,
    browser: "chrome"
  });

  gulp.watch(
    ['src/sass/**/*.scss', 'src/js/*.js'],
    ['build','lint', browserSync.reload]
  );
});

gulp.task('lint', ['stylelint', 'eslint']);
gulp.task('build', ['twig', 'sass', 'babel', 'imagemin']);
gulp.task('server', ['browsersync']);

gulp.task('default', ['lint', 'build']);
