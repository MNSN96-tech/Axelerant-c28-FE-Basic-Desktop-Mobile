(function global() {
	function formValidation()
{
var vfname = document.contact.validationfullname;
var vemail = document.contact.validationemail;
var vphone = document.contact.validationphonenum;
var flag;

if(fullname_validation(vfname,5,10))
{
	if(email_validation(vemail))
	{
		if(phone_validation(vphone,10,13))
		{
		}
	}
}
	return false;
}
function fullname_validation(vfname,min,max)
{
var letters = /^[A-Za-z]+$/;
var fname_len = vfname.value.length;
if(fname_len == 0 || fname_len >= max || fname_len < min)
{
	alert("Fullname should not be empty / length should be between "+min+" and "+max);
	vfname.focus();
	return false;
}
else if(vfname.value.match(letters))
{
	flag = 0;
	return true;
}
}
function email_validation(vemail)
{
var mailformat = /^\w+([\.-\]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(vemail.value.match(mailformat))
{
	flag = 0;
	return true;
}
else
{
	alert("You have entered an invalid email address!");
	vemail.focus();
	return false;
}
}
function phone_validation(vphone,min,max)
{
var numbers = /^[0-9]+$/;
var phone_len = vphone.value.length;
if(phone_len == 0 || phone_len >= max || phone_len < min)
{
	alert("Fullname should not be empty / length should be between "+min+" and "+max);
	vphone.focus();
	return false;
}
else if(vphone.value.match(numbers))
{
	flag = 0;
	return true;
}
if(flag=0){
	alert('Form successfully submitted');
	window.location.reload()
	return true;
}
}
})();
