function openNav(){
document.getElementById("div-sidebar").style.width="150px";
}
function closeNav(){
document.getElementById("div-sidebar").style.width="0";
}